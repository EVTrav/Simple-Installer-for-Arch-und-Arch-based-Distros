./2a.out
sudo pacman -Rns eclipse-cpp
