Installation:

1) Extract this archive
2) Open Terminal here
3) type ./Eclipse-Installer.sh
4) Choose listed Options

Unistallation:

1) Extract this archive
2) Open Terminal here
3) type ./Eclipse-Unistaller.sh

