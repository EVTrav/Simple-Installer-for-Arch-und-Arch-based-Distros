./a.out
git clone https://aur.archlinux.org/eclipse-cpp.git

cd eclipse-cpp

makepkg -si
